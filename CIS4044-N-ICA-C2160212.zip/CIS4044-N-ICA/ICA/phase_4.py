import requests
import pandas as pd
import sqlite3
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from datetime import datetime, timedelta

# Function to set up a retry mechanism for API requests
def requests_retry_session(retries=3, backoff_factor=0.3, status_forcelist=(500, 502, 504)):
    """
    Creates a retry-enabled session for HTTP requests.

    Parameters:
    - retries: Number of retries for each request.
    - backoff_factor: Backoff factor for exponential backoff.
    - status_forcelist: HTTP status codes to retry on.

    Returns:
    - Session object with retry mechanism.
    """
    session = requests.Session()
    retry = Retry(
        total=retries,          # Total number of retries
        read=retries,           # Number of retries on read errors
        connect=retries,        # Number of retries on connection errors
        backoff_factor=backoff_factor,  # Backoff factor for retries
        status_forcelist=status_forcelist  # HTTP status codes to retry on
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)    # Mount the adapter for HTTP
    session.mount('https://', adapter)   # Mount the adapter for HTTPS
    return session

# Function to fetch weather data from Open-Meteo API
def fetch_weather_data(city_name, country_name, latitude, longitude, start_date, end_date):
    """
    Fetches weather data from Open-Meteo API for a specified city and date range.

    Parameters:
    - city_name: Name of the city.
    - country_name: Name of the country.
    - latitude: Latitude of the city.
    - longitude: Longitude of the city.
    - start_date: Start date (datetime object).
    - end_date: End date (datetime object).

    Returns:
    - DataFrame containing fetched weather data or None if no data fetched.
    """
    # List to hold all dataframes
    all_dataframes = []

    # Iterate over the date range in chunks (e.g., 7 days at a time)
    current_date = start_date
    while current_date <= end_date:
        next_date = min(current_date + timedelta(days=6), end_date)
        
        # API endpoint and parameters
        url = "https://archive-api.open-meteo.com/v1/archive"
        params = {
            "latitude": latitude,
            "longitude": longitude,
            "daily": "temperature_2m_max,temperature_2m_min,wind_speed_10m_max,wind_gusts_10m_max",
            "timezone": "auto",
            "start_date": current_date.strftime('%Y-%m-%d'),
            "end_date": next_date.strftime('%Y-%m-%d')
        }
        
        try:
            # Make the API request with retry mechanism
            response = requests_retry_session().get(url, params=params, timeout=10)
            response.raise_for_status()
            
            # Parse the JSON response
            json_response = response.json()
            daily_data = json_response.get('daily', {})
            dates = pd.date_range(start=current_date, end=next_date)
            
            # Ensure all arrays have the same length
            data_length = min(len(dates), 
                              len(daily_data.get("temperature_2m_max", [])),
                              len(daily_data.get("temperature_2m_min", [])),
                              len(daily_data.get("wind_speed_10m_max", [])),
                              len(daily_data.get("wind_gusts_10m_max", [])))
            
            # Create a DataFrame from the JSON data
            daily_dataframe = pd.DataFrame({
                "date": dates[:data_length],
                "temperature_2m_max": daily_data.get("temperature_2m_max", [])[:data_length],
                "temperature_2m_min": daily_data.get("temperature_2m_min", [])[:data_length],
                "wind_speed_10m_max": daily_data.get("wind_speed_10m_max", [])[:data_length],
                "wind_gusts_10m_max": daily_data.get("wind_gusts_10m_max", [])[:data_length]
            })
            
            # Append the DataFrame to the list
            all_dataframes.append(daily_dataframe)
            
        except requests.exceptions.RequestException as e:
            print(f"An error occurred while fetching data for {city_name}: {e}")
            if hasattr(e, 'response'):
                print(f"Response status code: {e.response.status_code}")
                print(f"Response content: {e.response.content}")
        
        # Move to the next date chunk
        current_date = next_date + timedelta(days=1)
    
    # Concatenate all dataframes
    if all_dataframes:
        full_dataframe = pd.concat(all_dataframes, ignore_index=True)
        return full_dataframe
    else:
        return None

# Function to save data to Excel file
def save_to_excel(dataframe, city_name, country_name, start_date, end_date):
    """
    Saves weather data DataFrame to an Excel file.

    Parameters:
    - dataframe: DataFrame containing weather data.
    - city_name: Name of the city.
    - country_name: Name of the country.
    - start_date: Start date (datetime object).
    - end_date: End date (datetime object).
    """
    try:
        filename = f"{city_name}_{country_name}_weather_data_{start_date.strftime('%Y%m%d')}_{end_date.strftime('%Y%m%d')}.xlsx"
        dataframe.to_excel(filename, index=False)
        print(f"Successfully saved data to {filename}")
        
        # Display the data on console
        print("Weather Data:")
        print(dataframe)
        
    except PermissionError:
        print(f"Permission denied: Unable to save {filename}. The file might be open in another program.")
    except Exception as e:
        print(f"An unexpected error occurred while saving the Excel file: {e}")

# Function to save data to SQLite database
def save_to_database(dataframe, city_name, country_name, db_path):
    """
    Saves weather data DataFrame to an SQLite database.

    Parameters:
    - dataframe: DataFrame containing weather data.
    - city_name: Name of the city.
    - country_name: Name of the country.
    - db_path: Path to SQLite database file.
    """
    try:
        # Connect to the SQLite database
        connection = sqlite3.connect(db_path)
        cursor = connection.cursor()

        # Create a table for the city's weather data if it doesn't exist
        table_name = f'{city_name.replace(" ", "_")}_{country_name.replace(" ", "_")}_weather_data'
        cursor.execute(f'''
        CREATE TABLE IF NOT EXISTS {table_name} (
            date TEXT,
            temperature_2m_max REAL,
            temperature_2m_min REAL,
            wind_speed_10m_max REAL,
            wind_gusts_10m_max REAL
        );
        ''')

        # Insert the DataFrame into the SQLite database
        dataframe.to_sql(table_name, connection, if_exists='replace', index=False)

        # Commit the transaction
        connection.commit()
        print(f"{city_name}, {country_name} weather data has been added to the database.")
        
        # Display the data on console
        print("Weather Data:")
        print(dataframe)

    except sqlite3.Error as e:
        print(f"A database error occurred: {e}")
    finally:
        # Ensure the database connection is closed
        if 'connection' in locals():
            connection.close()

# Interactive function to select a city and date range
def interactive_weather_data_retrieval(db_path):
    """
    Interactive function to fetch weather data for a city and save to Excel, SQLite database, or both.

    Parameters:
    - db_path: Path to SQLite database file.
    """
    # Get user input for city details
    city_name = input("Enter the city name: ")
    country_name = input("Enter the country name: ")
    latitude = float(input("Enter the latitude: "))
    longitude = float(input("Enter the longitude: "))

    # Get user input for date range
    start_date_str = input("Enter the start date (YYYY-MM-DD): ")
    end_date_str = input("Enter the end date (YYYY-MM-DD): ")
    start_date = datetime.strptime(start_date_str, '%Y-%m-%d')
    end_date = datetime.strptime(end_date_str, '%Y-%m-%d')

    # Fetch weather data
    weather_data = fetch_weather_data(city_name, country_name, latitude, longitude, start_date, end_date)

    if weather_data is not None:
        # Ask user for saving options
        print("Choose saving options:")
        print("1. Save to Excel")
        print("2. Save to Database")
        print("3. Save to both Excel and Database")
        save_option = input("Enter your choice (1/2/3): ")

        # Save to Excel
        if save_option in ['1', '3']:
            save_to_excel(weather_data, city_name, country_name, start_date, end_date)

        # Save to Database
        if save_option in ['2', '3']:
            save_to_database(weather_data, city_name, country_name, db_path)
    else:
        print(f"No data available for {city_name}, {country_name} in the specified date range.")

# Path to the SQLite database
db_path = "db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db"

# Run the interactive function
interactive_weather_data_retrieval(db_path)
