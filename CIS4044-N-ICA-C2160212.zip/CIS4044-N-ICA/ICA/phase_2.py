import sqlite3
import matplotlib.pyplot as plt

# Establish database connection
connection = sqlite3.connect('db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db')

# Specify the start date and cities of interest
start_date = '2021-01-08'
cities_of_interest = ['London', 'Paris', 'Middlesbrough']
placeholders = ', '.join('?' for _ in cities_of_interest)

# Function to fetch average precipitation data
def get_average_precipitation_data(connection, cities_of_interest, start_date):
    query = """
            SELECT cities.name, AVG(daily_weather_entries.precipitation) AS avg_precipitation
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE cities.name IN ({})
            AND date BETWEEN ? AND DATE(?, '+6 day')
            GROUP BY cities.name
            ORDER BY cities.name;
            """.format(placeholders)
    cursor = connection.cursor()
    cursor.execute(query, (*cities_of_interest, start_date, start_date))
    return cursor.fetchall()

# Function to plot bar chart for precipitation
def plot_precipitation(datas, start_date):
    cities, avg_precipitation = zip(*datas)
    
    plt.figure(figsize=(10, 5))
    plt.bar(cities, avg_precipitation, color='red')
    plt.xlabel('City')
    plt.ylabel('Average Precipitation (mm)')
    plt.title(f'Average Precipitation over 7 days starting from {start_date}')
    plt.tight_layout()
    plt.show()

# Fetch data and plot
datas = get_average_precipitation_data(connection, cities_of_interest, start_date)
plot_precipitation(datas, start_date)

# Close database connection
connection.close()

# PLOT 2


# Establish database connection
db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
connection = sqlite3.connect(db_path)

# Specify the date range and cities of interest
start_date = '2021-03-24'
end_date = '2021-04-24'
specified_cities = ['London', 'Paris', 'Middlesbrough', 'Toulouse']

# Function to fetch precipitation data for specified cities
def get_precipitation_data_for_cities(connection, specified_cities, start_date, end_date):
    placeholders = ', '.join('?' for city in specified_cities)
    query = """
            SELECT cities.name, AVG(daily_weather_entries.precipitation) AS avg_precipitation
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE cities.name IN ({})
            AND date BETWEEN ? AND ?
            GROUP BY cities.name
            ORDER BY cities.name;
            """.format(placeholders)
    cursor = connection.cursor()
    cursor.execute(query, (*specified_cities, start_date, end_date))
    return cursor.fetchall()

# Function to plot bar chart for precipitation of specified cities
def plot_precipitation_for_cities(datas, start_date, end_date):
    cities, avg_precipitation = zip(*datas)
    
    plt.figure(figsize=(10, 5))
    plt.bar(cities, avg_precipitation, color='purple')
    plt.xlabel('City')
    plt.ylabel('Average Precipitation (mm)')
    plt.title(f'Average Precipitation from {start_date} to {end_date} for Specified Cities')
    plt.tight_layout()
    plt.show()

# Fetch data and plot
datas = get_precipitation_data_for_cities(connection, specified_cities, start_date, end_date)
plot_precipitation_for_cities(datas, start_date, end_date)

# Close database connection
connection.close()


# PLOT 3


# Establish database connection
db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
connection = sqlite3.connect(db_path)

# Specify the year for analysis
year = '2020'

# Function to fetch average yearly precipitation by country
def get_average_yearly_precipitation_by_country(connection, year):
    query = """
            SELECT countries.name, AVG(daily_weather_entries.precipitation) AS avg_precipitation
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            JOIN countries ON cities.country_id = countries.id
            WHERE strftime('%Y', daily_weather_entries.date) = ?
            GROUP BY countries.name
            ORDER BY countries.name;
            """
    cursor = connection.cursor()
    cursor.execute(query, (year,))
    return cursor.fetchall()

# Function to plot bar chart for average yearly precipitation by country
def plot_precipitation_by_country(datas, year):
    countries, avg_precipitation = zip(*datas)
    
    plt.figure(figsize=(10, 5))
    plt.bar(countries, avg_precipitation, color='blue')
    plt.xlabel('Country')
    plt.ylabel('Average Yearly Precipitation (mm)')
    plt.title(f'Average Yearly Precipitation for {year}')
    plt.tight_layout()
    plt.show()

# Fetch data and plot
datas = get_average_yearly_precipitation_by_country(connection, year)
plot_precipitation_by_country(datas, year)

# Close database connection
connection.close()


# PLOT 4
import numpy as np

# Establish database connection
db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
connection = sqlite3.connect(db_path)

# Specify the date and cities for analysis
selected_date = '2021-03-26'
cities_of_interest = ['London', 'Paris', 'Middlesbrough', 'Toulouse']

# Function to fetch weather data for selected cities on a specific date
def get_weather_data_for_cities(connection, cities_of_interest, selected_date):
    placeholders = ', '.join('?' for _ in cities_of_interest)
    query = """
            SELECT cities.name, 
                   daily_weather_entries.min_temp AS min_temp, 
                   daily_weather_entries.max_temp AS max_temp, 
                   daily_weather_entries.mean_temp AS mean_temp,
                   daily_weather_entries.precipitation AS total_precipitation
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE cities.name IN ({})
            AND date = ?
            GROUP BY cities.name
            ORDER BY cities.name;
            """.format(placeholders)
    cursor = connection.cursor()
    cursor.execute(query, (*cities_of_interest, selected_date))
    return cursor.fetchall()

# Function to plot grouped bar chart for weather data
def plot_grouped_bar_chart(datas, selected_date):
    cities, min_temps, max_temps, mean_temps, precipitations = zip(*datas)

    # Define the width of the bars
    barWidth = 0.2

    # Set position of bars on X axis
    r1 = np.arange(len(cities))
    r2 = [x + barWidth for x in r1]
    r3 = [x + barWidth for x in r2]
    r4 = [x + barWidth for x in r3]

    # Plotting
    plt.bar(r1, min_temps, color='blue', width=barWidth, edgecolor='grey', label='Min Temp')
    plt.bar(r2, max_temps, color='red', width=barWidth, edgecolor='grey', label='Max Temp')
    plt.bar(r3, mean_temps, color='green', width=barWidth, edgecolor='grey', label='Mean Temp')
    plt.bar(r4, precipitations, color='purple', width=barWidth, edgecolor='grey', label='Precipitation')

    # Adding labels
    plt.xlabel('City', fontweight='bold', fontsize=15)
    plt.ylabel('Values', fontweight='bold', fontsize=15)
    plt.xticks([r + barWidth for r in range(len(cities))], cities)
    plt.title(f'Min/Max/Mean temperature and precipitation values for {selected_date}')

    # Adding legend and displaying plot
    plt.legend()
    plt.show()

# Fetch data and plot
datas = get_weather_data_for_cities(connection, cities_of_interest, selected_date)
plot_grouped_bar_chart(datas, selected_date)

# Close database connection
connection.close()


# PLOT 5
# Establish database connection
db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
connection = sqlite3.connect(db_path)

# Specify the city and date range for analysis
city_name = 'Paris'
start_date = '2021-01-01'
end_date = '2021-01-31'

# Function to fetch daily weather data for the specified city
def get_daily_weather_data(connection, city_name, start_date, end_date):
    query = """
            SELECT date, 
                   daily_weather_entries.mean_temp AS mean_temp,
                   daily_weather_entries.precipitation AS precipitation
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE cities.name = ? AND date BETWEEN ? AND ?
            ORDER BY date;
            """
    cursor = connection.cursor()
    cursor.execute(query, (city_name, start_date, end_date))
    return cursor.fetchall()

# Function to plot multiple line chart for temperature and precipitation
def plot_temperature_precipitation_line_chart(data, city_name, start_date, end_date):
    dates, mean_temps, precipitations = zip(*data)

    plt.figure(figsize=(12, 6))
    plt.plot(dates, mean_temps, label='Mean Temperature (°C)', color='red', marker='o')
    plt.plot(dates, precipitations, label='Precipitation (mm)', color='blue', marker='x')

    plt.xlabel('Date')
    plt.ylabel('Values')
    plt.title(f'Temperature and Precipitation for {city_name} from {start_date} to {end_date}')
    plt.legend()
    plt.grid(True)
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

# Fetch data and plot
data = get_daily_weather_data(connection, city_name, start_date, end_date)
plot_temperature_precipitation_line_chart(data, city_name, start_date, end_date)

# Close database connection
connection.close()




# PLOT 6



# Establish a connection to the database
# This connects to the SQLite database file 'CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
connection = sqlite3.connect(db_path)

# Define the date range for the data you want to analyze
start_date = '2020-01-01'
end_date = '2021-12-31'

# Function to query the database for average temperature and rainfall data
def get_weather_data(connection, start_date, end_date):
    # SQL query to retrieve average temperature and rainfall for each city within the specified date range
    query = """
            SELECT cities.name, 
                   AVG(daily_weather_entries.mean_temp) AS avg_temperature, 
                   AVG(daily_weather_entries.precipitation) AS avg_rainfall
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE date BETWEEN ? AND ?
            GROUP BY cities.name
            ORDER BY cities.name;
            """
    # Execute the query and fetch the results
    cursor = connection.cursor()
    cursor.execute(query, (start_date, end_date))
    return cursor.fetchall()

# Function to plot the average temperature vs average rainfall
def plot_temperature_rainfall(data, start_date, end_date):
    # Unpack the data into separate lists for cities, average temperatures, and average rainfall
    cities, avg_temperature, avg_rainfall = zip(*data)
    
    # Create a scatter plot
    plt.figure(figsize=(10, 6))
    plt.scatter(avg_temperature, avg_rainfall, color='blue')
    
    # Annotate each point with the corresponding city name
    for i, city in enumerate(cities):
        plt.text(avg_temperature[i], avg_rainfall[i], city, fontsize=9, ha='right')
    
    # Set the labels and title for the plot
    plt.xlabel('Average Temperature (°C)')
    plt.ylabel('Average Rainfall (mm)')
    plt.title(f'Average Temperature vs. Average Rainfall ({start_date} to {end_date})')
    
    # Add a grid for better readability
    plt.grid(True)
    
    # Display the plot
    plt.show()

# Retrieve the weather data using the specified date range
data = get_weather_data(connection, start_date, end_date)

# Plot the retrieved data
plot_temperature_rainfall(data, start_date, end_date)

# Close the database connection
# It's a good practice to close the connection once you're done with database operations
connection.close()