import tkinter as tk
from tkinter import ttk
import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

# Global constant for database path
DATABASE_PATH = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'

# Phase 1: Initialization
# Initialize tkinter application for data visualization
class VisualizationApp:
    def __init__(self, root):
        """
        Initialize the VisualizationApp.

        Parameters:
        - root: The tkinter root window object.
        """
        self.root = root
        self.root.title("Data Visualization App")
        self.query_index = 0
        self.visualization_index = 0
        self.create_widgets()
        self.canvas_frame = None

    def create_widgets(self):
        """
        Create GUI widgets (buttons) for the application.
        """
        ttk.Button(self.root, text="Perform Next Query", command=self.perform_next_query).pack(side=tk.LEFT, padx=10, pady=10)
        ttk.Button(self.root, text="Show Next Visualization", command=self.show_next_visualization).pack(side=tk.LEFT, padx=10, pady=10)
        ttk.Button(self.root, text="Delete Data", command=self.delete_data).pack(side=tk.LEFT, padx=10, pady=10)
        ttk.Button(self.root, text="Quit", command=self.quit_app).pack(side=tk.LEFT, padx=10, pady=10)

    # Phase 2: Configuration
    # Functions to fetch data and plot data
    def fetch_data(self, query, params=()):
        """
        Fetch data from the SQLite database.

        Parameters:
        - query: SQL query string.
        - params: Parameters for the query.

        Returns:
        - List of tuples containing query results.
        """
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute(query, params)
        data = cursor.fetchall()
        conn.close()
        return data

    def plot_data(self, query, params=(), title="Plot", xlabel="X-axis", ylabel="Y-axis"):
        """
        Plot data from the SQLite database.

        Parameters:
        - query: SQL query string for fetching data.
        - params: Parameters for the query.
        - title: Title for the plot.
        - xlabel: Label for the x-axis.
        - ylabel: Label for the y-axis.

        Returns:
        - Matplotlib figure object.
        """
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        cursor.execute(query, params)
        data = cursor.fetchall()
        conn.close()

        if data:
            x, y = zip(*data)
            fig, ax = plt.subplots(figsize=(10, 5))
            ax.bar(x, y, color='blue')
            ax.set_title(title)
            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)
            return fig
        else:
            print("No data available to plot.")
            return None

    # Phase 3: Execution
    # Methods for performing queries, visualizing data, and interacting with GUI
    def perform_next_query(self):
        """
        Perform the next query based on the current index.
        """
        self.clear_canvas()
        queries = [self.select_all_countries, self.select_all_cities, self.calculate_average_annual_temperature]
        if self.query_index < len(queries):
            queries[self.query_index]()
            self.query_index += 1
        if self.query_index >= len(queries):
            self.query_index = 0

    def show_next_visualization(self):
        """
        Show the next visualization based on the current index.
        """
        self.clear_canvas()
        visualizations = [self.plot_average_precipitation_data, self.plot_precipitation_for_specified_cities, self.plot_yearly_precipitation_by_country]
        if self.visualization_index < len(visualizations):
            visualizations[self.visualization_index]()
            self.visualization_index += 1
        if self.visualization_index >= len(visualizations):
            self.visualization_index = 0

    def select_all_countries(self):
        """
        Perform a query to select all countries from the database.
        Display the result in a DataFrame.
        """
        query = "SELECT * FROM countries"
        data = self.fetch_data(query)
        df = pd.DataFrame(data, columns=['ID', 'Country', 'Timezone'])
        self.display_dataframe(df, "Countries")

    def select_all_cities(self):
        """
        Perform a query to select all cities from the database.
        Display the result in a DataFrame.
        """
        query = "SELECT * FROM cities"
        data = self.fetch_data(query)
        df = pd.DataFrame(data, columns=['ID', 'City', 'Longitude', 'Latitude', 'Country ID'])
        self.display_dataframe(df, "Cities")

    def calculate_average_annual_temperature(self):
        """
        Perform a query to calculate the average annual temperature for a specific city and year.
        Display the result in a DataFrame.
        """
        city_id = 1  # Example City ID
        year = '2020'  # Example Year
        query = "SELECT AVG(mean_temp) FROM daily_weather_entries WHERE city_id = ? AND strftime('%Y', date) = ?"
        data = self.fetch_data(query, (city_id, year))
        if data:
            df = pd.DataFrame(data, columns=['Average Temperature'])
            self.display_dataframe(df, f"Average Temperature for City ID {city_id} in {year}")

    def plot_average_precipitation_data(self):
        """
        Perform a query to plot the average precipitation data for a specified date range.
        Display the plot using Matplotlib.
        """
        start_date = '2021-01-08'
        end_date = '2021-01-14'
        query = """
        SELECT cities.name, AVG(daily_weather_entries.precipitation) as avg_precipitation 
        FROM daily_weather_entries 
        JOIN cities ON daily_weather_entries.city_id = cities.id 
        WHERE date BETWEEN ? AND ? 
        GROUP BY cities.name 
        ORDER BY cities.name
        """
        fig = self.plot_data(query, (start_date, end_date), 
                             title=f'Average Precipitation from {start_date} to {end_date}', 
                             xlabel='City', ylabel='Average Precipitation (mm)')
        if fig:
            self.display_figure(fig)

    def plot_precipitation_for_specified_cities(self):
        """
        Perform a query to plot the average precipitation data for specified cities and date range.
        Display the plot using Matplotlib.
        """
        start_date = '2021-03-24'
        end_date = '2021-04-24'
        cities_of_interest = ['London', 'Paris', 'Middlesbrough', 'Toulouse']
        placeholders = ', '.join('?' * len(cities_of_interest))
        query = f"""
        SELECT cities.name, AVG(daily_weather_entries.precipitation) as avg_precipitation 
        FROM daily_weather_entries 
        JOIN cities ON daily_weather_entries.city_id = cities.id 
        WHERE cities.name IN ({placeholders}) AND date BETWEEN ? AND ? 
        GROUP BY cities.name 
        ORDER BY cities.name
        """
        fig = self.plot_data(query, (*cities_of_interest, start_date, end_date), 
                             title=f'Average Precipitation from {start_date} to {end_date} for Specified Cities', 
                             xlabel='City', ylabel='Average Precipitation (mm)')
        if fig:
            self.display_figure(fig)

    def plot_yearly_precipitation_by_country(self):
        """
        Perform a query to plot the average yearly precipitation data for a specific year.
        Display the plot using Matplotlib.
        """
        year = '2020'
        query = """
        SELECT countries.name, AVG(daily_weather_entries.precipitation) as avg_precipitation 
        FROM daily_weather_entries 
        JOIN cities ON daily_weather_entries.city_id = cities.id 
        JOIN countries ON cities.country_id = countries.id 
        WHERE strftime('%Y', daily_weather_entries.date) = ? 
        GROUP BY countries.name 
        ORDER BY countries.name
        """
        fig = self.plot_data(query, (year,), 
                             title=f'Average Yearly Precipitation for {year}', 
                             xlabel='Country', ylabel='Average Yearly Precipitation (mm)')
        if fig:
            self.display_figure(fig)

    def delete_data(self):
        """
        Perform a deletion operation on the database.
        Delete a specific city record based on its name.
        """
        connection = sqlite3.connect(DATABASE_PATH)
        cursor = connection.cursor()
        try:
            table_name = 'cities'
            city_name_to_delete = 'Toulouse'
            cursor.execute(f"SELECT * FROM {table_name} WHERE name = ?", (city_name_to_delete,))
            record = cursor.fetchone()
            if record:
                print(f"Record found: {record}. Proceeding with delete.")
                cursor.execute(f"DELETE FROM {table_name} WHERE name = ?", (city_name_to_delete,))
                connection.commit()
                cursor.execute(f"SELECT * FROM {table_name} WHERE name = ?", (city_name_to_delete,))
                record = cursor.fetchone()
                if record:
                    print(f"Record still exists after delete: {record}")
                else:
                    print(f"Record deleted successfully. No record with name = {city_name_to_delete}.")
            else:
                print(f"No record found with name = {city_name_to_delete}. Nothing to delete.")
        except sqlite3.Error as e:
            print(f"SQLite error: {e}")
        finally:
            connection.close()

    # Phase 4: Cleanup
    # Methods for clearing canvas and displaying data
    def clear_canvas(self):
        """
        Clear the canvas frame if it exists.
        """
        if self.canvas_frame:
            self.canvas_frame.destroy()
            self.canvas_frame = None

    def display_dataframe(self, df, title):
        """
        Display a DataFrame in the application.
        
        Parameters:
        - df: DataFrame containing data to display.
        - title: Title for the displayed DataFrame.
        """
        if self.canvas_frame:
            self.canvas_frame.destroy()
        self.canvas_frame = tk.Frame(self.root)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
        label = tk.Label(self.canvas_frame, text=title, font=('Arial', 16))
        label.pack()
        text = tk.Text(self.canvas_frame, wrap=tk.NONE)
        text.pack(fill=tk.BOTH, expand=True)
        text.insert(tk.END, df.to_string())
        text.config(state=tk.DISABLED)

    def display_figure(self, fig):
        """
        Display a Matplotlib figure in the application.
        
        Parameters:
        - fig: Matplotlib figure object to display.
        """
        if self.canvas_frame:
            self.canvas_frame.destroy()
        self.canvas_frame = tk.Frame(self.root)
        self.canvas_frame.pack(fill=tk.BOTH, expand=True)
        canvas = FigureCanvasTkAgg(fig, master=self.canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def quit_app(self):
        """
        Quit the application.
        """
        self.root.quit()

if __name__ == "__main__":
    # Initialize tkinter root window
    root = tk.Tk()
    # Create an instance of VisualizationApp
    app = VisualizationApp(root)
    # Start the tkinter main event loop
    root.mainloop()
