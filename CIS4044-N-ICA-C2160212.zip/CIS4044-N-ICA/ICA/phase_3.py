import sqlite3
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns  # Import Seaborn
from datetime import datetime, timedelta

class ConsoleVisualizationApp:
    def __init__(self, db_path):
        self.db_path = db_path

    def select_all_countries(self):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM countries;")
            results = cursor.fetchall()
            connection.close()
            for row in results:
                print(row)
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def select_all_cities(self):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM cities;")
            results = cursor.fetchall()
            connection.close()
            for row in results:
                print(row)
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def calculate_average_annual_temperature(self, city_id, year):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT AVG(mean_temp)
                FROM daily_weather_entries
                WHERE city_id = ? AND strftime('%Y', date) = ?;
            """, (city_id, year))
            result = cursor.fetchone()
            connection.close()
            if result:
                print(f"Average annual temperature for city ID {city_id} in {year} is {result[0]:.2f}°C")
            else:
                print(f"No data available for city ID {city_id} in {year}.")
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def calculate_average_seven_day_precipitation(self, city_id, start_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            end_date = (datetime.strptime(start_date, "%Y-%m-%d") + timedelta(days=6)).strftime("%Y-%m-%d")
            cursor.execute("""
                SELECT AVG(precipitation)
                FROM daily_weather_entries
                WHERE city_id = ? AND date BETWEEN ? AND ?;
            """, (city_id, start_date, end_date))
            result = cursor.fetchone()
            connection.close()
            if result:
                print(f"Average 7-day precipitation for city ID {city_id} from {start_date} to {end_date} is {result[0]:.2f} mm")
            else:
                print(f"No data available for city ID {city_id} from {start_date} to {end_date}.")
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def average_mean_temp_by_city(self, date_from, date_to):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT cities.name, AVG(daily_weather_entries.mean_temp)
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE date BETWEEN ? AND ?
                GROUP BY cities.name
                ORDER BY cities.name;
            """, (date_from, date_to))
            results = cursor.fetchall()
            connection.close()
            for row in results:
                print(f"{row[0]}: {row[1]:.2f}°C")
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def average_annual_precipitation_by_country(self, year):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT countries.name, AVG(daily_weather_entries.precipitation)
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                JOIN countries ON cities.country_id = countries.id
                WHERE strftime('%Y', daily_weather_entries.date) = ?
                GROUP BY countries.name
                ORDER BY countries.name;
            """, (year,))
            results = cursor.fetchall()
            connection.close()
            for row in results:
                print(f"{row[0]}: {row[1]:.2f} mm")
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def plot_bar_chart_precipitation_data(self, start_date, end_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT cities.name, AVG(daily_weather_entries.precipitation) as avg_precipitation
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE date BETWEEN ? AND ?
                GROUP BY cities.name
                ORDER BY cities.name;
            """, (start_date, end_date))
            results = cursor.fetchall()
            connection.close()

            if results:
                cities, avg_precipitation = zip(*results)
                fig, ax = plt.subplots(figsize=(10, 5))
                ax.bar(cities, avg_precipitation, color='red')
                ax.set_xlabel('City')
                ax.set_ylabel('Average Precipitation (mm)')
                ax.set_title(f'Average Precipitation from {start_date} to {end_date}')
                plt.xticks(rotation=45, ha='right')
                plt.tight_layout()
                plt.show()
            else:
                print('No data available for the specified date range.')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def plot_pie_chart_precipitation_by_country(self, year):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT countries.name, AVG(daily_weather_entries.precipitation) as avg_precipitation
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                JOIN countries ON cities.country_id = countries.id
                WHERE strftime('%Y', daily_weather_entries.date) = ?
                GROUP BY countries.name
                ORDER BY countries.name;
            """, (year,))
            results = cursor.fetchall()
            connection.close()

            if results:
                countries, avg_precipitation = zip(*results)
                plt.figure(figsize=(10, 5))
                plt.pie(avg_precipitation, labels=countries, autopct='%1.1f%%', colors=sns.color_palette("Blues", len(countries)))
                plt.title(f'Average Yearly Precipitation for {year}')
                plt.show()
            else:
                print('No data available')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def plot_bar_chart_temperature(self, city_name, start_date, end_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT date, min_temp, max_temp
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE cities.name = ? AND date BETWEEN ? AND ?
                ORDER BY date;
            """, (city_name, start_date, end_date))
            results = cursor.fetchall()
            connection.close()

            if results:
                dates, min_temps, max_temps = zip(*results)
                fig, ax = plt.subplots(figsize=(10, 5))
                ax.bar(dates, min_temps, color='green', label='Min Temp')
                ax.bar(dates, max_temps, color='lightgreen', label='Max Temp', alpha=0.7)
                ax.set_xlabel('Date')
                ax.set_ylabel('Temperature')
                ax.set_title(f'Temperature Distribution for {city_name} from {start_date} to {end_date}')
                plt.xticks(rotation=45, ha='right')
                plt.legend()
                plt.tight_layout()
                plt.show()
            else:
                print('No data available for the specified date range.')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def plot_grouped_bar_chart(self, start_date, end_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT cities.name, AVG(daily_weather_entries.mean_temp) as avg_temperature, 
                       AVG(daily_weather_entries.precipitation) as avg_rainfall
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE date BETWEEN ? AND ?
                GROUP BY cities.name
                ORDER BY cities.name;
            """, (start_date, end_date))
            results = cursor.fetchall()
            connection.close()

            if results:
                cities, avg_temperature, avg_rainfall = zip(*results)
                fig, ax = plt.subplots(figsize=(10, 5))
                width = 0.35
                x = range(len(cities))
                ax.bar(x, avg_temperature, width, label='Avg Temperature', color='blue')
                ax.bar([p + width for p in x], avg_rainfall, width, label='Avg Rainfall', color='orange')
                ax.set_xlabel('City')
                ax.set_ylabel('Values')
                ax.set_title(f'Average Temperature and Rainfall from {start_date} to {end_date}')
                ax.set_xticks([p + width / 2 for p in x])
                ax.set_xticklabels(cities, rotation=45, ha='right')
                ax.legend()
                plt.tight_layout()
                plt.show()
            else:
                print('No data available for the specified date range.')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def plot_line_chart_precipitation(self, start_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT cities.name, daily_weather_entries.precipitation
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE date >= ?
                ORDER BY cities.name;
            """, (start_date,))
            results = cursor.fetchall()
            connection.close()

            if results:
                data = {}
                for city, precipitation in results:
                    if city not in data:
                        data[city] = []
                    data[city].append(precipitation)
                city_names = list(data.keys())
                precipitation_data = [data[city] for city in city_names]
                fig, ax = plt.subplots(figsize=(10, 5))
                for city, precip in zip(city_names, precipitation_data):
                    ax.plot(precip, label=city)
                ax.set_xlabel('Time')
                ax.set_ylabel('Precipitation (mm)')
                ax.set_title(f'Precipitation from {start_date}')
                plt.xticks(rotation=45, ha='right')
                plt.legend()
                plt.tight_layout()
                plt.show()
            else:
                print('No data available from the specified start date.')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def plot_scatter_chart_temperature_rainfall(self, start_date, end_date):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            cursor.execute("""
                SELECT cities.name, AVG(daily_weather_entries.mean_temp) as avg_temperature, 
                       AVG(daily_weather_entries.precipitation) as avg_rainfall
                FROM daily_weather_entries
                JOIN cities ON daily_weather_entries.city_id = cities.id
                WHERE date BETWEEN ? AND ?
                GROUP BY cities.name
                ORDER BY cities.name;
            """, (start_date, end_date))
            results = cursor.fetchall()
            connection.close()

            if results:
                cities, avg_temperature, avg_rainfall = zip(*results)
                fig, ax = plt.subplots(figsize=(10, 5))
                scatter = ax.scatter(avg_temperature, avg_rainfall, c=range(len(cities)), cmap='viridis')
                ax.set_xlabel('Average Temperature (°C)')
                ax.set_ylabel('Average Rainfall (mm)')
                ax.set_title(f'Temperature and Rainfall from {start_date} to {end_date}')
                plt.colorbar(scatter, ax=ax, label='City Index')
                for i, city in enumerate(cities):
                    ax.annotate(city, (avg_temperature[i], avg_rainfall[i]))
                plt.tight_layout()
                plt.show()
            else:
                print('No data available for the specified date range.')
        except sqlite3.OperationalError as e:
            print(f"Error: {e}")

    def delete_data(self, table_name, condition):
        try:
            connection = sqlite3.connect(self.db_path)
            cursor = connection.cursor()
            query = f"DELETE FROM {table_name} WHERE {condition};"
            cursor.execute(query)
            connection.commit()
            connection.close()
            print("Data deleted successfully.")
        except sqlite3.OperationalError as e:
            print(f"Database error: {e}")
        except Exception as e:
            print(f"An unexpected error occurred: {e}")

    def run(self):
        while True:
            print("\nMenu:")
            print("1. Select all countries")
            print("2. Select all cities")
            print("3. Calculate average annual temperature for a city")
            print("4. Calculate average 7-day precipitation for a city")
            print("5. Average mean temperature by city")
            print("6. Average annual precipitation by country")
            print("7. Bar chart for precipitation data by city")
            print("8. Pie chart for precipitation data by country")
            print("9. Bar chart for temperature data by city")
            print("10. Grouped bar chart for temperature and rainfall data")
            print("11. Line chart for precipitation data")
            print("12. Scatter plot for temperature and rainfall data")
            print("13. Delete data from table")
            print("14. Quit")
            choice = input("Enter choice: ")

            if choice == '1':
                self.select_all_countries()
            elif choice == '2':
                self.select_all_cities()
            elif choice == '3':
                city_id = int(input("Enter city ID: "))
                year = input("Enter year (YYYY): ")
                self.calculate_average_annual_temperature(city_id, year)
            elif choice == '4':
                city_id = int(input("Enter city ID: "))
                start_date = input("Enter start date (YYYY-MM-DD): ")
                self.calculate_average_seven_day_precipitation(city_id, start_date)
            elif choice == '5':
                date_from = input("Enter start date (YYYY-MM-DD): ")
                date_to = input("Enter end date (YYYY-MM-DD): ")
                self.average_mean_temp_by_city(date_from, date_to)
            elif choice == '6':
                year = input("Enter year (YYYY): ")
                self.average_annual_precipitation_by_country(year)
            elif choice == '7':
                start_date = input("Enter start date (YYYY-MM-DD): ")
                end_date = input("Enter end date (YYYY-MM-DD): ")
                self.plot_bar_chart_precipitation_data(start_date, end_date)
            elif choice == '8':
                year = input("Enter year (YYYY): ")
                self.plot_pie_chart_precipitation_by_country(year)
            elif choice == '9':
                city_name = input("Enter city name: ")
                start_date = input("Enter start date (YYYY-MM-DD): ")
                end_date = input("Enter end date (YYYY-MM-DD): ")
                self.plot_bar_chart_temperature(city_name, start_date, end_date)
            elif choice == '10':
                start_date = input("Enter start date (YYYY-MM-DD): ")
                end_date = input("Enter end date (YYYY-MM-DD): ")
                self.plot_grouped_bar_chart(start_date, end_date)
            elif choice == '11':
                start_date = input("Enter start date (YYYY-MM-DD): ")
                self.plot_line_chart_precipitation(start_date)
            elif choice == '12':
                start_date = input("Enter start date (YYYY-MM-DD): ")
                end_date = input("Enter end date (YYYY-MM-DD): ")
                self.plot_scatter_chart_temperature_rainfall(start_date, end_date)
            elif choice == '13':
                table_name = input("Enter table name: ")
                condition = input("Enter condition for deletion: ")
                self.delete_data(table_name, condition)
            elif choice == '14':
                print("Exiting...")
                break
            else:
                print("Invalid choice. Please enter a number between 1 and 14.")

if __name__ == "__main__":
    db_path = 'db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db'
    app = ConsoleVisualizationApp(db_path)
    app.run()
