#PHASE 1
1. select_all_countries
Purpose: Retrieves and prints details of all countries stored in the 'countries' table.
Operation: Establishes a connection to the database, executes a SELECT query on the 'countries' table to fetch all rows, and prints each country's ID, name, and timezone.
Notes: Uses a try-except-finally block to handle potential errors and ensures proper closure of the cursor.
2. select_all_cities
Purpose: Retrieves and prints details of all cities stored in the 'cities' table.
Operation: Establishes a connection to the SQLite database, executes a SELECT query on the 'cities' table to fetch all rows, and prints each city's ID, name, longitude, latitude, and associated country ID.
Notes: Uses try-except-finally to handle potential SQLite operational errors and ensures closure of the cursor to release resources.
3. average_annual_temperature
Purpose: Calculates and prints the average annual temperature for a specific city and year.
Operation: Takes parameters city_id and year, executes an SQL query to calculate the average mean temperature from 'daily_weather_entries' for the given city and year, and prints the result.
Notes: Uses SQLite's strftime function to extract the year from the Date column and formats the output. Handles potential errors and ensures proper closure of the cursor.
4. average_seven_day_precipitation
Purpose: Calculates and prints the average precipitation over a seven-day period for a specific city starting from a given date.
Operation: Takes parameters city_id and start_date, executes an SQL query to calculate the average precipitation from 'daily_weather_entries' for the specified city and date range, and prints the result.
Notes: Uses SQLite's date function to calculate the end date of the seven-day period and formats the output. Handles potential errors and ensures proper closure of the cursor.
5. average_mean_temp_by_city
Purpose: Calculates and prints the average mean temperature for each city within a specified date range.
Operation: Takes parameters date_from and date_to, executes an SQL query to calculate the average mean temperature from 'daily_weather_entries' for each city within the given date range, and prints the results.
Notes: Uses SQLite's JOIN operation to link 'daily_weather_entries' and 'cities' tables based on city_id, groups results by city name, and formats the output. Handles potential errors and ensures proper closure of the cursor.
6. average_annual_precipitation_by_country
Purpose: Calculates and prints the average annual precipitation for each country in a specified year.



# PHASE 2
Plot 1
Purpose:
Fetches and visualizes the average precipitation for specified cities over a 7-day period starting from a given date.

Functions Used:

get_average_precipitation_data(connection, cities_of_interest, start_date)
Fetches the average precipitation for specified cities over a 7-day period.
plot_precipitation(datas, start_date)
Generates a bar chart showing the average precipitation for each city.
Plot 2
Purpose:
Retrieves and visualizes the average precipitation for specified cities over a custom date range.

Functions Used:

get_precipitation_data_for_cities(connection, specified_cities, start_date, end_date)
Retrieves the average precipitation for specified cities over the given date range.
plot_precipitation_for_cities(datas, start_date, end_date)
Creates a bar chart displaying the average precipitation for each city.
Plot 3
Purpose:
Fetches and visualizes the average yearly precipitation for each country in a specified year.

Functions Used:

get_average_yearly_precipitation_by_country(connection, year)
Retrieves the average yearly precipitation for each country.
plot_precipitation_by_country(datas, year)
Plots a bar chart of average yearly precipitation for each country.
Plot 4
Purpose:
Fetches and visualizes weather data (min, max, mean temperatures, and precipitation) for specified cities on a specific date.

Functions Used:

get_weather_data_for_cities(connection, cities_of_interest, selected_date)
Retrieves weather data for specified cities on the given date.
plot_grouped_bar_chart(datas, selected_date)
Generates a grouped bar chart showing min, max, mean temperatures, and precipitation for each city.
Plot 5
Purpose:
Fetches and visualizes daily weather data (mean temperature and precipitation) for a specified city over a given date range.

Functions Used:

get_daily_weather_data(connection, city_name, start_date, end_date)
Retrieves daily weather data for the specified city over the date range.
plot_temperature_precipitation_line_chart(data, city_name, start_date, end_date)
Creates a line chart showing daily mean temperatures and precipitation for the city.
Plot 6
Purpose:
Fetches and visualizes average temperature and rainfall data for each city within a specified date range.

Functions Used:

get_weather_data(connection, start_date, end_date)
Fetches average temperature and rainfall data for each city within the date range.
plot_temperature_rainfall(data, start_date, end_date)
Plots a scatter chart showing average temperature vs. average rainfall for each city.




#PHASE 3
Features
Data Retrieval and Display
Select All Countries

Retrieves and displays all countries from the database.
Select All Cities

Retrieves and displays all cities from the database.
Data Calculations
Calculate Average Annual Temperature for a City

Computes the average annual temperature for a specified city and year.
Calculate Average 7-Day Precipitation for a City

Computes the average precipitation over a 7-day period for a specified city starting from a given date.
Average Mean Temperature by City

Calculates the average mean temperature for each city within a specified date range.
Average Annual Precipitation by Country

Computes the average annual precipitation for each country for a specified year.
Data Visualization
Bar Chart for Precipitation Data by City

Plots a bar chart showing average precipitation for each city within a specified date range.
Pie Chart for Precipitation Data by Country

Displays a pie chart of average annual precipitation for each country for a specified year.
Bar Chart for Temperature Data by City

Plots a bar chart showing minimum and maximum temperatures for a specified city within a date range.
Grouped Bar Chart for Temperature and Rainfall Data

Plots a grouped bar chart showing average temperature and rainfall for each city within a specified date range.
Line Chart for Precipitation Data

Plots a line chart showing daily precipitation for each city from a specified start date.
Scatter Plot for Temperature and Rainfall Data

Displays a scatter plot showing average temperature versus average rainfall for each city within a specified date range.
Data Management
Delete Data from Table
Deletes data from a specified table based on a given condition.
Menu Navigation
Quit
Exits the application.



#PHASE 4
Features
Data Retrieval: The script interacts with the Open-Meteo API to retrieve weather data such as maximum and minimum temperatures, maximum wind speed, and maximum wind gusts for a specified city over a chosen date range.

Retry Mechanism: Utilizes a retry mechanism to handle potential API request failures (e.g., due to network issues) and retries requests a configurable number of times.

Data Storage Options: After fetching the data, you can choose to save it:

To Excel: Saves the weather data into an Excel file with a customizable filename.
To SQLite Database: Stores the weather data in an SQLite database table named after the city and country.
Both: Optionally, you can save the data to both Excel and SQLite database simultaneously.