# Function 1: select_all_countries
# Purpose: Retrieves and prints details of all countries stored in the 'countries' table.
# Operation: Establishes a connection to the database using SQLite, executes a SELECT query
#            on the 'countries' table to fetch all rows, and prints each country's ID,
#            name, and timezone.
# Notes: Uses a try-except-finally block to handle potential errors such as operational
#        errors from SQLite and ensures proper closure of the cursor to release resources.

import sqlite3

def select_all_countries(connection):
    try:
        # Define SQL query to select all columns from 'countries' table
        query = "SELECT * FROM countries"

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query
        results = cursor.execute(query)

        # Iterate over the results and print each row with formatted details
        for row in results:
            print(f"Country Id: {row[0]} -- Country Name: {row[1]} -- Country Timezone: {row[2]}")

    except sqlite3.OperationalError as ex:
        # Handle potential errors, such as table not found or other operational issues
        print(ex)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database and call the function
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Call the function to retrieve and display all countries
    select_all_countries(connection)

    # Close the database connection when finished
    connection.close()


# Function 2: select_all_cities
# Purpose: Retrieves and prints details of all cities stored in the 'cities' table.
# Operation: Establishes a connection to the SQLite database, executes a SELECT query
#            on the 'cities' table to fetch all rows, and prints each city's ID, name,
#            longitude, latitude, and associated country ID.
# Notes: Uses try-except-finally to handle potential SQLite operational errors and ensures
#        closure of the cursor to release resources after execution.

import sqlite3

def select_all_cities(connection):
    try:
        # Define SQL query to select all columns from 'cities' table
        query = "SELECT * FROM cities"

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query
        cursor.execute(query)

        # Fetch all results into a list of tuples
        results = cursor.fetchall()

        # Iterate over the results and print each city's details with formatted output
        for row in results:
            city_id, city_name, longitude, latitude, country_id = row
            print(f"City Id: {city_id} -- City Name: {city_name} -- City longitude: {float(longitude):.2f} -- City latitude: {float(latitude):.2f} -- Country Id: {country_id}")

    except sqlite3.OperationalError as ex:
        # Handle potential errors, such as table not found or other operational issues
        print(ex)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database and call the function
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Call the function to retrieve and display all cities
    select_all_cities(connection)

    # Close the database connection when finished
    connection.close()


# Function 3: average_annual_temperature
# Purpose: Calculates and prints the average annual temperature for a specific city and year.
# Operation: Takes parameters city_id and year, executes an SQL query to calculate the average
#            mean temperature from 'daily_weather_entries' for the given city and year, and
#            prints the result. Handles potential errors and ensures proper closure of the cursor.
# Notes: Uses SQLite's strftime function to extract the year from Date column and formats the output.

import sqlite3

def average_annual_temperature(connection, city_id, year):
    try:
        # Define SQL query to calculate average mean temperature for specified city and year
        query = """
            SELECT AVG(mean_temp) 
            FROM daily_weather_entries 
            WHERE city_id = ? AND strftime('%Y', Date) = ?
        """

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query with parameters city_id and year
        cursor.execute(query, (city_id, year))

        # Fetch the result of the query
        result = cursor.fetchone()

        # Check if result exists and print the average temperature
        if result:
            print(f"Average temperature for City ID {city_id} in {year}: {result[0]}")
        else:
            print(f"No data found for City ID {city_id} in {year}")

    except sqlite3.OperationalError as ex:
        # Handle potential SQLite operational errors
        print(ex)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database, prompt user for input, and call the function
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Prompt user for City ID and Year
    city_id = input("Enter City ID: ")
    year = input("Enter Year: ")

    # Call the function to calculate and display average annual temperature
    average_annual_temperature(connection, city_id, year)

    # Close the database connection when finished
    connection.close()


# Function 4: average_seven_day_precipitation
# Purpose: Calculates and prints the average precipitation over a seven-day period for a specific city starting from a given date.
# Operation: Takes parameters city_id and start_date, executes an SQL query to calculate the average precipitation from
#            'daily_weather_entries' for the specified city and date range, and prints the result. Handles potential errors
#            and ensures proper closure of the cursor.
# Notes: Uses SQLite's date function to calculate the end date of the seven-day period and formats the output.

import sqlite3

def average_seven_day_precipitation(connection, city_id, start_date):
    try:
        # Define SQL query to calculate average precipitation over a seven-day period for specified city and start date
        query = """
        SELECT AVG(precipitation)
        FROM daily_weather_entries
        WHERE city_id = ? AND Date BETWEEN ? AND date(?, '+6 days')
        """

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query with parameters city_id and start_date
        cursor.execute(query, (city_id, start_date, start_date))

        # Fetch the result of the query
        avg_precipitation, = cursor.fetchone()

        # Print the average precipitation over seven days starting from start_date
        print(f"City_id: {city_id} -- Average precipitation for seven days starting from {start_date}: {avg_precipitation}")

    except sqlite3.OperationalError as ex:
        # Handle potential SQLite operational errors
        print(ex)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database and call the function with predefined values
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Predefined values for city_id and start_date
    city_id = 1
    start_date = '2020-01-01'

    # Call the function to calculate and display average seven-day precipitation
    average_seven_day_precipitation(connection, city_id, start_date)

    # Close the database connection when finished
    connection.close()


# Function 5: average_mean_temp_by_city
# Purpose: Calculates and prints the average mean temperature for each city within a specified date range.
# Operation: Takes parameters date_from and date_to, executes an SQL query to calculate the average mean
#            temperature from 'daily_weather_entries' for each city within the given date range, and prints
#            the results. Handles potential errors and ensures proper closure of the cursor.
# Notes: Uses SQLite's JOIN operation to link 'daily_weather_entries' and 'cities' tables based on city_id,
#        groups results by city name, and formats the output.

import sqlite3

def average_mean_temp_by_city(connection, date_from, date_to):
    try:
        # Define SQL query to calculate average mean temperature by city within specified date range
        query = """
            SELECT cities.name, AVG(daily_weather_entries.mean_temp)
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            WHERE daily_weather_entries.date >= ? AND daily_weather_entries.date <= ?
            GROUP BY cities.name;
        """

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query with parameters date_from and date_to
        cursor.execute(query, (date_from, date_to))

        # Fetch all results
        results = cursor.fetchall()

        # Check if results exist and print
        if results:
            for city, avg_temp in results:
                print(f"{city}: {avg_temp}°C")
        else:
            print(f"No data available for the given date range: {date_from} to {date_to}")

    except sqlite3.Error as e:
        # Handle potential SQLite errors
        print("SQLite error:", e)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database, prompt user for input, and call the function
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Prompt user for start date and end date
    date_from = input("Enter start date (YYYY-MM-DD): ")
    date_to = input("Enter end date (YYYY-MM-DD): ")

    # Call the function to calculate and display average mean temperature by city
    average_mean_temp_by_city(connection, date_from, date_to)

    # Close the database connection when finished
    connection.close()

# Function 6: average_annual_precipitation_by_country
# Purpose: Calculates and prints the average annual precipitation for each country in a specified year.
# Operation: Takes a parameter 'year', executes an SQL query to calculate the average precipitation from
#            'daily_weather_entries' for each country by joining with 'cities' and 'countries' tables based
#            on city_id and country_id, and groups results by country name. The results are printed for each country.
# Notes: Uses SQLite's strftime function to extract the year from the Date column, handles potential errors,
#        and ensures the cursor is closed to release resources properly.

import sqlite3

def average_annual_precipitation_by_country(connection, year):
    try:
        # Define SQL query to calculate average annual precipitation for each country in the specified year
        query = """
            SELECT countries.name, AVG(daily_weather_entries.precipitation)
            FROM daily_weather_entries
            JOIN cities ON daily_weather_entries.city_id = cities.id
            JOIN countries ON cities.country_id = countries.id
            WHERE strftime('%Y', daily_weather_entries.date) = ?
            GROUP BY countries.name;
        """

        # Create a cursor object to execute queries on the database
        cursor = connection.cursor()

        # Execute the query with the parameter year
        cursor.execute(query, (year,))

        # Fetch all results
        results = cursor.fetchall()

        return results

    except sqlite3.Error as e:
        # Handle potential SQLite errors
        print("SQLite error:", e)

    finally:
        # Ensure the cursor is closed to release database resources
        cursor.close()

# Main block to connect to the database, prompt user for input, and display the results
if __name__ == "__main__":
    # Establish connection to the SQLite database using a relative path
    connection = sqlite3.connect("db/CIS4044-N-SDI-OPENMETEO-PARTIAL.db")

    # Prompt user for the year
    year = input("Enter the year (YYYY): ")

    # Call the function to calculate and retrieve average annual precipitation by country
    results = average_annual_precipitation_by_country(connection, year)

    # Check if results are available and print them
    if results:
        for country, avg_precipitation in results:
            print(f"The average precipitation for your selected year {year} for country {country} is this: {avg_precipitation:.2f} mm")

    # Close the database connection when finished
    connection.close()
